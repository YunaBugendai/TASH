@echo off
cd /d "%~dp0\.."
python -m worker.worker_app
