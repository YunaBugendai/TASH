@echo off
cd /d "%~dp0\.."
python -m master.master_app
