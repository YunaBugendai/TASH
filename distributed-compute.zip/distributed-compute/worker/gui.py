"""
Tkinter GUI for the Worker application.

Same pattern as the Master GUI: the networking layer (worker_core.py)
never touches tkinter. It reports state changes through `on_event`,
which is wired here to a thread-safe queue.Queue that `_poll_events`
drains on Tkinter's own mainloop.
"""
import queue
import time
import tkinter as tk
from tkinter import ttk, messagebox

from worker.worker_core import WorkerClient


class WorkerApp:
    def __init__(self, root, worker_name):
        self.root = root
        self.events = queue.Queue()
        self.client = WorkerClient(worker_name)
        self.client.on_event = lambda ev, data: self.events.put((ev, data))
        self._paused = False

        root.title(f"Distributed Compute -- Worker ({worker_name})")
        root.geometry("500x460")
        self._build_ui()
        self._poll_events()

    def _build_ui(self):
        conn = ttk.LabelFrame(self.root, text="Connect to Master")
        conn.pack(fill="x", padx=8, pady=8)

        ttk.Label(conn, text="Master IP:").grid(row=0, column=0, sticky="w", padx=4, pady=2)
        self.var_host = tk.StringVar(value="127.0.0.1")
        ttk.Entry(conn, textvariable=self.var_host, width=16).grid(row=0, column=1, padx=4)

        ttk.Label(conn, text="Port:").grid(row=0, column=2, sticky="w")
        self.var_port = tk.IntVar(value=8765)
        ttk.Entry(conn, textvariable=self.var_port, width=8).grid(row=0, column=3, padx=4)

        ttk.Label(conn, text="Pairing code:").grid(row=1, column=0, sticky="w", padx=4, pady=2)
        self.var_code = tk.StringVar()
        ttk.Entry(conn, textvariable=self.var_code, width=10).grid(row=1, column=1, padx=4)

        ttk.Button(conn, text="Find Master on LAN", command=self._discover).grid(
            row=1, column=2, padx=4)
        ttk.Button(conn, text="Connect", command=self._connect).grid(row=1, column=3, padx=4)

        status = ttk.LabelFrame(self.root, text="Status")
        status.pack(fill="x", padx=8, pady=8)
        self.lbl_state = ttk.Label(status, text="Disconnected", font=("TkDefaultFont", 12, "bold"))
        self.lbl_state.pack(anchor="w", padx=4, pady=2)
        self.lbl_master = ttk.Label(status, text="Master: --")
        self.lbl_master.pack(anchor="w", padx=4)
        self.lbl_task = ttk.Label(status, text="Current task: --")
        self.lbl_task.pack(anchor="w", padx=4)

        ctl = ttk.LabelFrame(self.root, text="Controls")
        ctl.pack(fill="x", padx=8, pady=8)
        ttk.Label(ctl, text="CPU usage limit (%):").grid(row=0, column=0, sticky="w", padx=4)
        self.var_cpu_limit = tk.IntVar(value=100)
        scale = ttk.Scale(ctl, from_=10, to=100, orient="horizontal",
                          variable=self.var_cpu_limit,
                          command=lambda v: self.client.set_cpu_limit(int(float(v))))
        scale.grid(row=0, column=1, sticky="ew", padx=4)
        ctl.columnconfigure(1, weight=1)

        btns = ttk.Frame(ctl)
        btns.grid(row=1, column=0, columnspan=2, pady=6)
        self.btn_pause = ttk.Button(btns, text="Pause", command=self._toggle_pause)
        self.btn_pause.pack(side="left", padx=4)
        ttk.Button(btns, text="Disconnect", command=self._disconnect).pack(side="left", padx=4)

        logs = ttk.LabelFrame(self.root, text="Logs")
        logs.pack(fill="both", expand=True, padx=8, pady=8)
        self.log_text = tk.Text(logs, state="disabled", height=8, wrap="word")
        self.log_text.pack(fill="both", expand=True)

    # ------------------------------------------------------------- actions

    def _discover(self):
        result = self.client.send_discovery_probe()
        if result:
            self.var_host.set(result[0])
            self.var_port.set(result[1])
            self._log(f"Found Master at {result[0]}:{result[1]}")
        else:
            self._log("No Master found on the local network. You can still enter an IP manually.")

    def _connect(self):
        host = self.var_host.get()
        port = self.var_port.get()
        code = self.var_code.get()
        if not code:
            messagebox.showwarning("Pairing code required",
                                   "Ask the Master operator for the pairing code shown on "
                                   "their screen.")
            return
        self.client.start(host, port, code)
        self._log(f"Connecting to {host}:{port}...")

    def _disconnect(self):
        self.client.disconnect_gracefully()
        self._log("Disconnected by user.")
        self.lbl_state.config(text="Disconnected")

    def _toggle_pause(self):
        self._paused = not self._paused
        self.client.set_paused(self._paused)
        self.btn_pause.config(text="Resume" if self._paused else "Pause")

    # ------------------------------------------------------------- events

    def _poll_events(self):
        try:
            while True:
                ev, data = self.events.get_nowait()
                self._handle_event(ev, data)
        except queue.Empty:
            pass
        self.root.after(200, self._poll_events)

    def _handle_event(self, ev, data):
        if ev == "awaiting_consent":
            self._ask_consent()
        elif ev == "connecting":
            self.lbl_state.config(text="Connecting...")
        elif ev == "authorized":
            self.lbl_state.config(text="Connected")
            self.lbl_master.config(text=f"Master: {data['master']}")
            self._log(f"Authorized by Master {data['master']}")
        elif ev == "rejected":
            self.lbl_state.config(text="Rejected")
            self._log(f"Master rejected connection: {data.get('reason')}")
        elif ev == "disconnected":
            self.lbl_state.config(text="Disconnected")
        elif ev == "reconnecting":
            self.lbl_state.config(text=f"Reconnecting in {data['in_seconds']}s...")
        elif ev == "connection_error":
            self._log(f"Connection error: {data.get('error')}")
        elif ev == "task_started":
            self.lbl_state.config(text="Computing...")
            self.lbl_task.config(text=f"Current task: chunk {data['chunk_id']}")
        elif ev == "task_completed":
            self.lbl_state.config(text="Connected")
            self.lbl_task.config(text="Current task: --")
            self._log(f"Completed chunk {data['chunk_id']}")
        elif ev == "task_failed":
            self.lbl_task.config(text="Current task: --")
            self._log(f"Chunk {data['chunk_id']} failed: {data.get('error')}")
        elif ev == "task_cancelled":
            self._log("Master cancelled the current job.")
        elif ev == "paused":
            self.lbl_state.config(text="Paused")
        elif ev == "resumed":
            self.lbl_state.config(text="Connected")
        else:
            self._log(f"{ev}: {data}")

    def _ask_consent(self):
        answer = messagebox.askyesno(
            "Authorize this Master?",
            f"A Master at {self.var_host.get()} wants to use this computer as a Worker.\n\n"
            "It will only ever be able to run predefined computational tasks that ship with "
            "this application -- never arbitrary commands. You can pause or disconnect at "
            "any time.\n\nAuthorize it?")
        self.client.set_user_authorized(answer)
        if not answer:
            self._log("You declined to authorize this Master.")
            self.client.stop()

    def _log(self, text):
        self.log_text.config(state="normal")
        self.log_text.insert("end", f"[{time.strftime('%H:%M:%S')}] {text}\n")
        self.log_text.see("end")
        self.log_text.config(state="disabled")
